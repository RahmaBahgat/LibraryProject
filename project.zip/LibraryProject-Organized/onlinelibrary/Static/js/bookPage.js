// Book Page Controller
document.addEventListener("DOMContentLoaded", function () {
  // Setup event listeners
  document.getElementById("fav-btn")?.addEventListener("click", toggleFavorite);
  document.getElementById("borrow-btn")?.addEventListener("click", toggleBorrow);

  // If the book data wasn't properly rendered in the template, try to get it from the URL
  const bookId = getBookIdFromUrl();
  if (bookId && document.querySelector(".book-title").textContent === "Book Title") {
    fetchBookData(bookId);
  }
});

// Get book ID from URL
function getBookIdFromUrl() {
  const pathParts = window.location.pathname.split("/");
  const bookIndex = pathParts.findIndex(part => part === 'book');
  if (bookIndex !== -1 && bookIndex + 1 < pathParts.length) {
    return pathParts[bookIndex + 1];
  }
  return null;
}

function fetchBookData(bookId) {
  fetch(`/api/books/${bookId}/`)
    .then((response) => {
      if (!response.ok) throw new Error("Book not found");
      return response.json();
    })
    .then((data) => {
      updateBookPage(data.book);
    })
    .catch((error) => {
      console.error("Error fetching book:", error);
    });
}

function updateBookPage(book) {
  if (!book) return;

  // Update required fields
  document.querySelector(".book-title").textContent = book.title;
  document.querySelector(".book-author").textContent = book.author;
  document.querySelector(".p-description").textContent = book.description;

  // Update category
  const categoryElement = document.querySelector(".book-category");
  if (book.category) {
    categoryElement.textContent = Array.isArray(book.category)
      ? book.category.join(", ")
      : book.category;
  } else if (book.genre) {
    categoryElement.textContent = book.genre;
  } else {
    categoryElement.textContent = "Uncategorized";
  }

  // Update book cover
  const imgContainer = document.querySelector(".img-container img");
  if (imgContainer) {
    imgContainer.src = book.image || book.cover_path || "/static/images/books/default-cover.jpg";
    imgContainer.alt = `${book.title} cover`;
  }

  updateFavoriteButton(book);
  updateBorrowButton(book);
}

function updateFavoriteButton(book) {
  const favBtn = document.getElementById("fav-btn");
  if (!favBtn) return;

  const icon = favBtn.querySelector(".icon");
  const text = favBtn.querySelector(".fav-text");

  icon.textContent = book.is_favorite ? "❤️" : "♡";
  text.textContent = book.is_favorite ? "Remove from Favorites" : "Add to Favorites";
  
  if (book.is_favorite) {
    favBtn.classList.add("favorited");
  } else {
    favBtn.classList.remove("favorited");
  }
}

function updateBorrowButton(book) {
  const borrowBtn = document.getElementById("borrow-btn");
  if (!borrowBtn) return;

  const icon = borrowBtn.querySelector(".icon");
  const text = borrowBtn.querySelector(".borrow-text");

  icon.textContent = "📚";
  text.textContent = book.is_borrowed ? "Return Book" : "Borrow Book";
  
  if (book.is_borrowed) {
    borrowBtn.classList.add("borrowed");
  } else {
    borrowBtn.classList.remove("borrowed");
  }
}

// Get CSRF token from cookie
function getCSRFToken() {
  const name = "csrftoken";
  let cookieValue = null;
  if (document.cookie && document.cookie !== "") {
    const cookies = document.cookie.split(";");
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i].trim();
      if (cookie.substring(0, name.length + 1) === name + "=") {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}

// Toggle favorite status
async function toggleFavorite() {
  const bookId = getBookIdFromUrl();
  if (!bookId) {
    console.error("No book ID found in URL");
    return;
  }

  try {
    const response = await fetch(`/book/${bookId}/toggle-favorite/`, {
      method: "POST",
      headers: {
        "X-CSRFToken": getCSRFToken(),
        "Content-Type": "application/json",
      },
      credentials: "same-origin",
    });

    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const data = await response.json();

    if (data.success) {
      const favBtn = document.getElementById("fav-btn");
      const icon = favBtn.querySelector(".icon");
      const text = favBtn.querySelector(".fav-text");

      if (data.is_favorite) {
        icon.textContent = "❤️";
        text.textContent = "Remove from Favorites";
        favBtn.classList.add("favorited");
      } else {
        icon.textContent = "♡";
        text.textContent = "Add to Favorites";
        favBtn.classList.remove("favorited");
      }
      showNotification(data.message || "Favorite status updated successfully", "success");
    } else {
      throw new Error(data.message || "Failed to toggle favorite status");
    }
  } catch (error) {
    console.error("Error toggling favorite:", error);
    showNotification(error.message || "Failed to update favorite status", "error");
  }
}

// Toggle borrow status
async function toggleBorrow() {
  const bookId = getBookIdFromUrl();
  if (!bookId) {
    console.error("No book ID found in URL");
    return;
  }

  try {
    const response = await fetch(`/book/${bookId}/toggle-borrow/`, {
      method: "POST",
      headers: {
        "X-CSRFToken": getCSRFToken(),
        "Content-Type": "application/json",
      },
      credentials: "same-origin",
    });

    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const data = await response.json();

    if (data.success) {
      const borrowBtn = document.getElementById("borrow-btn");
      const icon = borrowBtn.querySelector(".icon");
      const text = borrowBtn.querySelector(".borrow-text");

      if (data.is_borrowed) {
        icon.textContent = "📚";
        text.textContent = "Return Book";
        borrowBtn.classList.add("borrowed");
      } else {
        icon.textContent = "📚";
        text.textContent = "Borrow Book";
        borrowBtn.classList.remove("borrowed");
      }
      showNotification(data.message || "Borrow status updated successfully", "success");
    } else {
      throw new Error(data.message || "Failed to toggle borrow status");
    }
  } catch (error) {
    console.error("Error toggling borrow:", error);
    showNotification(error.message || "Failed to update borrow status", "error");
  }
}

// Helper function to show notifications
function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  notification.textContent = message;
  
  document.body.appendChild(notification);
  
  // Trigger animation
  setTimeout(() => {
    notification.classList.add('show');
  }, 100);
  
  // Remove notification after 3 seconds
  setTimeout(() => {
    notification.classList.remove('show');
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, 3000);
}
